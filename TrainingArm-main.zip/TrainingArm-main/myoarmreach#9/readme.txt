# Policy hyperparameters
policy_size = (256, 256)
seed = 123
rl_step_size = 0.1
learnrate = 0.025
entcoeff = 0.01
batchsize = 32
num_epoch = 10

# Value Function hyperparameters
vf_hidden_size = (256, 256)
seed = 123
rl_step_size = 0.1
learnrate = 0.025
entcoeff = 0.01
batchsize = 32
num_epoch = 10
regcoef = 0.001